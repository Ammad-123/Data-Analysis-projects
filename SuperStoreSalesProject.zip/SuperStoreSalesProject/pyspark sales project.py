# Databricks notebook source


# COMMAND ----------

dbutils.widgets.dropdown("time_period","Weekly",["Weekly","Monthly"])

# COMMAND ----------

from datetime import date, timedelta, datetime
from pyspark.sql.functions import *

time_period = dbutils.widgets.get("time_period")
print(time_period)
today = date.today()

if time_period == 'Weekly':
    start_date = today-timedelta(days=today.weekday(),weeks=1)-timedelta(days=1)
    end_date = start_date+timedelta(days=6)
else:
    first = today.replace(day=1)
    end_date = first-timedelta(days=1)
    start_date = first-timedelta(days=end_date.day)

print(start_date, end_date)

# COMMAND ----------

df = spark.read.csv("/FileStore/tables/superstore.csv",header=True , inferSchema=True)
display(df)

# COMMAND ----------

df.createOrReplaceTempView("sample_superstore")

# COMMAND ----------

# MAGIC %sql SELECT * FROM sample_superstore

# COMMAND ----------

# DBTITLE 1,total number of customer
# MAGIC %sql SELECT COUNT(DISTINCT customer_id) FROM sample_superstore

# COMMAND ----------

# DBTITLE 1,total number of customer has done the order last week/month
# %sql SELECT COUNT(DISTINCT customer_id) FROM sample_superstore WHERE order_date BETWEEN '2024-06-01' and '2024-06-30'
display(spark.sql(f"""SELECT COUNT(DISTINCT customer_id) FROM sample_superstore WHERE order_date BETWEEN '{start_date}' and '{end_date}'"""))

# COMMAND ----------

# DBTITLE 1,total number of order
# MAGIC %sql SELECT COUNT(DISTINCT order_id) FROM sample_superstore

# COMMAND ----------

# DBTITLE 1,total number of order has done in the last week/month
display(spark.sql(f"""SELECT COUNT(DISTINCT order_id) FROM sample_superstore WHERE order_date BETWEEN '{start_date}' and '{end_date}'"""))

# COMMAND ----------

# DBTITLE 1,total sales and profit
# MAGIC %sql SELECT SUM(sales) ,sum(profit) FROM sample_superstore

# COMMAND ----------

# DBTITLE 1,top sales by country
# MAGIC %sql SELECT SUM(sales),country FROM sample_superstore GROUP BY 2;

# COMMAND ----------

# DBTITLE 1,most profitable region and country
# MAGIC
# MAGIC %sql SELECT SUM(sales), country, region from sample_superstore GROUP BY 2,3 ORDER BY 1 DESC;

# COMMAND ----------

# DBTITLE 1,top sales category product
# MAGIC %sql SELECT SUM(sales),category FROM sample_superstore GROUP BY 2 ORDER BY 1 DESC;

# COMMAND ----------

# DBTITLE 1,top 10 sales sub category
# MAGIC %sql SELECT SUM(sales),sub_category FROM sample_superstore GROUP BY 2 ORDER BY 1 DESC LIMIT 10;

# COMMAND ----------

# DBTITLE 1,most order quantity product
# MAGIC %sql SELECT sum(quantity), product_name FROM sample_superstore GROUP BY 2 ORDER BY 1 DESC;

# COMMAND ----------

# DBTITLE 1,top customer name based on name and city
# MAGIC %sql SELECT SUM(sales), customer_name, city FROM sample_superstore GROUP BY 2,3 ORDER BY 1 DESC LIMIT 10;
